﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=WIN-K3GD8E8BACN\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
